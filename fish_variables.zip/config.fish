set -x LANG ko_KR.UTF-8
set -x LC_ALL ko_KR.UTF-8

if status is-interactive
    fish_add_path /mingw64/bin /usr/local/bin /usr/bin

    set -gx SHELL (status fish-path)
    set -gx MANROFFOPT "-c"
    set -gx MANPAGER "sh -c 'col -bx | bat -p -l man'"

    # Alias
    abbr -a ll 'ls -l'
    abbr -a ls 'ls -F --color=auto --show-control-chars'

    # Git
    abbr -a gs 'git status'
    abbr -a gp 'git push'
    abbr -a gl 'git log --oneline --graph'
    abbr -a gd 'git diff'

    fzf --fish | source
    set -gx FZF_DEFAULT_OPTS "--height 99%"
    set -gx FZF_DEFAULT_COMMAND "fd --no-ignore"
end
