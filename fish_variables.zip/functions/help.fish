function help
    if test (count $argv) -eq 0
        bat -l help
        return
    end
    $argv --help 2>/dev/null | bat -p -l help
end
