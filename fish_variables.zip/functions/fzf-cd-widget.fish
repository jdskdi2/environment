function fzf-cd-widget
    set -l commandline (__fzf_parse_commandline)
    set -lx dir $commandline[1]
    set -l fzf_query $commandline[2]
    set -l prefix $commandline[3]
    set -lx FZF_DEFAULT_OPTS (__fzf_defaults "--reverse --walker=dir,follow,hidden --scheme=path" "$FZF_ALT_C_OPTS --no-multi --print0")
    set -lx FZF_DEFAULT_OPTS_FILE
    set -lx FZF_DEFAULT_COMMAND "$FZF_ALT_C_COMMAND"
    if set -l result (eval (__fzfcmd) --query=$fzf_query --walker-root=$dir | string split0)
        cd -- (string replace -a "\\" "/" -- $result)
        commandline -rt -- $prefix
    end
    commandline -f repaint
end
