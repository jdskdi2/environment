function _fzf_search_processes --description "Search all running processes. Replace the current token with the pid of the selected process."
    set -f ps_cmd (command -v ps || echo "ps")
    # MSYS2/MinGW64 ps uses BSD-style flags, GNU/Linux uses POSIX
    if $ps_cmd -W 2>/dev/null | grep -q "WINPID"
        set -f processes_selected (
            $ps_cmd -e | \
            _fzf_wrapper --multi \
                        --prompt="Processes> " \
                        --query (commandline --current-token) \
                        --ansi \
                        --header-lines=1 \
                        --preview="$ps_cmd -p {1} -fl || echo 'Cannot preview {1} because it exited.'" \
                        --preview-window="bottom:4:wrap" \
                        $fzf_processes_opts
        )
    else
        # Linux: -A + -o format
        set -f ps_preview_fmt (string join ',' 'pid' 'ppid=PARENT' 'user' '%cpu' 'rss=RSS_IN_KB' 'start=START_TIME' 'command')
        set -f processes_selected (
            $ps_cmd -A -opid,command | \
            _fzf_wrapper --multi \
                        --prompt="Processes> " \
                        --query (commandline --current-token) \
                        --ansi \
                        --header-lines=1 \
                        --preview="$ps_cmd -o '$ps_preview_fmt' -p {1} || echo 'Cannot preview {1} because it exited.'" \
                        --preview-window="bottom:4:wrap" \
                        $fzf_processes_opts
        )
    end

    if test $status -eq 0
        for process in $processes_selected
            set -f --append pids_selected (string split --no-empty --field=1 -- " " $process)
        end

        # string join to replace the newlines outputted by string split with spaces
        commandline --current-token --replace -- (string join ' ' $pids_selected)
    end

    commandline --function repaint
end
