function fish_prompt
    set -l last_status $status

    set -l pwd (set_color 7dcfff)(prompt_pwd | string replace -a "\\" "/")(set_color normal)

    set -l git_info ''
    if git rev-parse --is-inside-work-tree >/dev/null 2>&1
        set -l branch (git branch --show-current 2>/dev/null)
        if test -n "$branch"
            set git_info (set_color 9ece6a)" ($branch)"(set_color normal)
        end
    end

    echo -n -s $pwd $git_info
    echo

    if test $last_status -eq 0
        echo -n -s (set_color bb9af7) '➜  ' (set_color normal)
    else
        echo -n -s (set_color f7768e) '➜  ' (set_color normal)
    end
end
