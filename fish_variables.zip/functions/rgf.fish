function rgf
    if test (count $argv) -eq 0
        echo "검색어를 입력해주세요."
        return 1
    end

    set -l search_query $argv
    set -l search_path "."
    
    if test (count $argv) -ge 2
        set search_path $argv[-1]
        set search_query $argv[1..-2]
    end

    # 1. rg로 '파일 경로:라인 번호:내용' 형태로 fzf에 넘깁니다.
    # 2. fzf 내부에서 {1}은 파일 경로, {2}는 라인 번호가 됩니다.
    rg --line-number --no-heading --color=always --smart-case -- "$search_query" "$search_path" | fzf \
        --delimiter ':' \
        --ansi \
        --border \
        --height 80% \
        --extended \
        --reverse \
        --cycle \
        --header 'Find in File' \
        --bind 'f1:execute(less -f {1}),ctrl-y:execute-silent(echo {1} | pbcopy)+abort' \
        --bind 'alt-p:preview-up,alt-n:preview-down' \
        --bind 'ctrl-u:half-page-up,ctrl-d:half-page-down' \
        --bind '?:toggle-preview,alt-w:toggle-preview-wrap' \
        --bind 'alt-v:execute(nvim +{2} {1} >/dev/tty </dev/tty)' \
        --preview "bat --theme='OneHalfDark' --style=numbers --color=always --highlight-line {2} {1} 2>/dev/null" \
        --preview-window "+{2}-10" 2>/dev/null
    
    if test $status -ne 0
        return 0
    end
    
    stty sane 2>/dev/null
end

