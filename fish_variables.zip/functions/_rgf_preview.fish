function _rgf_preview
    set -l line $argv[1]
    set -l file (string replace -r ':\d+:.*' '' -- $line)
    set -l num (string replace -r '.*:(\d+):.*' '$1' -- $line)
    set -l start (math "max(1, $num - 3)")
    set -l end (math "$num + 3")
    bat --color=always --line-range $start:$end --highlight-line $num $file
end
